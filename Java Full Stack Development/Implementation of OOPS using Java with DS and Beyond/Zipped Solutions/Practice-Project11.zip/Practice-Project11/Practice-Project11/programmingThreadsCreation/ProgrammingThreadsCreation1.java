package AssistedPractice.programmingThreadsCreation;

/**
 * Created by IntelliJ IDEA
 * User: Abhinav Bhardwaj
 * Date: 23/07/22
 * Time: 10:59
 */

// Creating thread by extending Thread Class
public class ProgrammingThreadsCreation1 extends Thread {
    @Override
    public void run() {
        System.out.println("Thread has been started.");
    }

    public static void main(String[] args) {
        ProgrammingThreadsCreation1 PTC = new ProgrammingThreadsCreation1();
        PTC.run();
    }
}
