package AssistedPractice.programmingThreadsCreation;

/**
 * Created by IntelliJ IDEA
 * User: Abhinav Bhardwaj
 * Date: 23/07/22
 * Time: 11:06
 */


// Creating thread by implementing Runnable Interface
public class ProgrammingThreadsCreation2 implements Runnable{


    public static int myCount = 0;

    @Override
    public void run() {
        while(ProgrammingThreadsCreation2.myCount <= 10){
            try{
                System.out.println("Expl Thread: "+(++ProgrammingThreadsCreation2.myCount));
                Thread.sleep(100);
            } catch (InterruptedException iex) {
                System.out.println("Exception in thread: "+iex.getMessage());
            }
        }
    }


    public static void main(String[] args) {
        System.out.println("Starting Main Thread...");
        ProgrammingThreadsCreation2 mrt = new ProgrammingThreadsCreation2();
        Thread t = new Thread(mrt);
        t.start();
        while(ProgrammingThreadsCreation2.myCount <= 10){
            try{
                System.out.println("Main Thread: "+(++ProgrammingThreadsCreation2.myCount));
                Thread.sleep(100);
            } catch (InterruptedException iex){
                System.out.println("Exception in main thread: "+iex.getMessage());
            }
        }
        System.out.println("End of Main Thread...");
    }
}
