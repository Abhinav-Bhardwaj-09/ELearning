package AssistedPractice.smallest4th;

import java.util.*;


/**
 * Created by IntelliJ IDEA
 * User: Abhinav Bhardwaj
 * Date: 25/07/22
 * Time: 20:31
 */


public class Smallest4th {
    public static void main(String[] args) {
        Scanner SC = new Scanner(System.in);

        int k = 4;
        boolean flag = false;

        System.out.print("Enter the no of elements : ");
        int size = SC.nextInt();
        flag = size >= 4 ? false : true;
        while (flag) {
            System.out.print("Please enter the no of elements  greater than 4: ");
            size = SC.nextInt();
            flag = size >= 4 ? false : true;
        }

        int[] arr = new int[size];

        System.out.print("Enter the the elements in the space seperated format : ");
        for(int i = 0; i < size; i++){
            arr[i] = SC.nextInt();
        }


        k--;

        Set<Integer> s = new TreeSet<>();

        for(int i=0; i < size; i++) {
            s.add(arr[i]);
        }

        Iterator<Integer> itr = s.iterator();

        while(k>0) {
            itr.next();
            k--;
        }

        System.out.println("Fourth smallest element: " + itr.next());
    }
}
