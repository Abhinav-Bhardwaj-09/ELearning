package AssistedPractice.rightRotate;

import java.util.Scanner;

/**
 * Created by IntelliJ IDEA
 * User: Abhinav Bhardwaj
 * Date: 25/07/22
 * Time: 23:07
 */


public class RightRotate {

    int [] RightRotation(int Arr[], int steps) {
        if(steps > 0 && steps <= Arr.length) {
            for(int s = 1; s <= steps; s++){
                int lastElement = Arr[Arr.length - 1];
                for (int index = Arr.length-1; index > 0; index--) {
                    Arr [index] = Arr[index - 1];
                }
                Arr[0] = lastElement;
            }
        }
        else {
            System.out.println("Please enter a valid input as step.");
        }
        return Arr;
    }

    public static void main(String[] args) {
        Scanner SC = new Scanner(System.in);
        RightRotate RR = new RightRotate();

        System.out.print("Size of the array: ");
        int size = SC.nextInt();

        int arr [] = new int[size];

        System.out.print("Enter elements of the array in space seperated format: ");
        for (int index = 0; index < size; index++) {
            arr[index] = SC.nextInt();
        }

        System.out.print("Steps for right rotation the array: ");
        int steps = SC.nextInt();

        System.out.print("Array before rotating: ");
        for (int element: arr) {
            System.out.print(element + " ");
        }

        System.out.println();
        arr = RR.RightRotation(arr, steps);

        System.out.print("Array after  rotating: ");

        for (int element: arr) {
            System.out.print(element + " ");
        }
    }
}
