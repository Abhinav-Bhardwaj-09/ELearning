package AssistedPractice.doublyLinkedList;


/**
 * Created by IntelliJ IDEA
 * User: Abhinav Bhardwaj
 * Date: 25/07/22
 * Time: 19:25
 */


public class Main {
    public static void main(String[] args) {
        DoublyLinkedList DLL = new DoublyLinkedList();

        DLL.insertAtEnd(5);
        DLL.insertAtEnd(7);
        DLL.insertAtEnd(2);
        DLL.insertAtEnd(9);
        DLL.insertAtEnd(12);
        DLL.insertAtEnd(1);
        DLL.insertAtEnd(18);
        DLL.insertAtEnd(11);
        DLL.insertAtEnd(14);

        DLL.displayH2T();   // To display elements from head to tail, i.e., forward traversing
        System.out.println();
        DLL.displayT2H();   // To display elements from tail to head, i.e., backward traversing

    }
}
