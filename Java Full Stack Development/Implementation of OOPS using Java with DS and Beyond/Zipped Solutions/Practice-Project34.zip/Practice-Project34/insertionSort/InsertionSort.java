package AssistedPractice.insertionSort;

import java.util.Scanner;

/**
 * Created by IntelliJ IDEA
 * User: Abhinav Bhardwaj
 * Date: 27/07/22
 * Time: 13:16
 */


public class InsertionSort {

    void insertionS (int arr[]) {
        for (int index1 = 1; index1 < arr.length; index1++){
            for (int index2 = 0; index2 < index1; index2++) {
                if (arr[index2] > arr[index1]) {
                    arr[index1] = arr[index1] + arr[index2];
                    arr[index2] = arr[index1] - arr[index2];
                    arr[index1] = arr[index1] - arr[index2];
                }
            }
        }
    }

    public static void main(String[] args) {
        InsertionSort IS = new InsertionSort();
        Scanner SC = new Scanner(System.in);

        System.out.print("Size of the array: ");
        int size = SC.nextInt();

        if(size <= 0 ) {
            boolean flag = true;
            while(flag) {
                System.out.println("\nInvalid Input !!!");
                System.out.print("Size of the array should be greater than 0: ");
                size = SC.nextInt();

                if(size > 0) {
                    flag = false;
                }
            }
        }

        int [] arr = new int[size];

        System.out.println();
        System.out.print("Enter the elements of the array in the space seperated format : ");
        for (int index = 0; index < size; index++) {
            arr[index] = SC.nextInt();
        }

        System.out.println();

        IS.insertionS(arr);

        System.out.print("Sorted array: ");
        for (int element:arr) {
            System.out.print(element + " ");
        }
    }
}
