package AssistedPractice.implementationOfQueue;

/**
 * Created by IntelliJ IDEA
 * User: Abhinav Bhardwaj
 * Date: 25/07/22
 * Time: 12:06
 */


public class QueueImplementation {
    private Node frontNode, rearNode;
    private int length = 0;

    // To return length of the Queue
    public int length() {
        return length;
    }



    // To check whether queue is empty or not
    public boolean isEmpty() {
        return length == 0;
    }



    // To add new element in the queue
    public void enqueue (int data) {
        Node newNode = new Node(data);
        System.out.println("Element enqueued in the Queue: " + data);



        if(isEmpty()) {
            frontNode = newNode;
            rearNode = newNode;
        }
        else {
            rearNode.setNextNode(newNode);
            rearNode = newNode;
        }

        length++;
        display();
        System.out.println("\n");
    }



    // To delete element in the queue
    public void dequeue() {
        if(isEmpty()) {
            System.out.println("Your queue is already empty.");
            return;
        }
        else {
            System.out.print("\nElement dequeued from the Queue: " + frontNode.getData());

            if(length == 1) {
                frontNode = null;
                rearNode = null;
                length--;
                return;
            }
            frontNode = frontNode.getNextNode();
            length--;
        }
    }



    // To display the elements of the queue
    public void display() {
        if(isEmpty()) {
            System.out.println("Your queue is empty, so no element to display.");
            return;
        }
        else if(length == 1) {
            System.out.print("(Start) " + frontNode.getData() + " (End)");
            return;
        }

        Node currentNode = frontNode;

        System.out.print("(Start) ");


        while (currentNode != rearNode) {
            Node temp = new Node(currentNode.getData());
            System.out.print(currentNode.getData() + " --> ");
            currentNode = currentNode.getNextNode();
        }
        System.out.print(currentNode.getData() + " (End)");
    }
}
