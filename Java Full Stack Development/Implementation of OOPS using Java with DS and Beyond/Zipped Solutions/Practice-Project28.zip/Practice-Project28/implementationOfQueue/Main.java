package AssistedPractice.implementationOfQueue;

/**
 * Created by IntelliJ IDEA
 * User: Abhinav Bhardwaj
 * Date: 25/07/22
 * Time: 12:07
 */


public class Main {
    public static void main(String[] args) {
        QueueImplementation QI = new QueueImplementation();

        System.out.println();
        System.out.println( QI.isEmpty() ? "Currently, Queue is empty." : "Currently, Queue is not empty.");

        System.out.println();

        QI.enqueue(7);
        System.out.println( QI.isEmpty() ? "Currently, Queue is empty." : "Currently, Queue is not empty.");
        System.out.println();

        QI.enqueue(16);
        QI.enqueue(5);
        QI.enqueue(11);

        QI.display();
        System.out.println();
        QI.dequeue();
        System.out.println();
        QI.display();
        System.out.println();
        QI.dequeue();
        System.out.println();
        QI.display();
    }
}
