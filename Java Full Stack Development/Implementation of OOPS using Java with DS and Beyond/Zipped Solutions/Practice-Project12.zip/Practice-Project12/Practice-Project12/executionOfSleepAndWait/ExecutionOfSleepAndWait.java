package AssistedPractice.executionOfSleepAndWait;

/**
 * Created by IntelliJ IDEA
 * User: Abhinav Bhardwaj
 * Date: 23/07/22
 * Time: 14:15
 */


public class ExecutionOfSleepAndWait {
    private static Object LOCK_Variable = new Object();
    public static void main(String args[]) throws InterruptedException {
        Thread t = new Thread();

        System.out.println("Execution of Sleep(): ");
        System.out.println("'" + Thread.currentThread().getName() + "' Thread is going to sleep for 5 sec.");
        t.sleep(5000);
        System.out.println("'" + Thread.currentThread().getName() + "' Thread woken up.\n\n");

        t.sleep(2000);

        synchronized (LOCK_Variable) {
            System.out.println("Execution of Sleep(): ");

            System.out.println("'" + LOCK_Variable + "' object is going for waiting period for 3 second.");
            LOCK_Variable.wait(3000);
            System.out.println("Object '" + LOCK_Variable + "' object is woken.");
        }
    }

}
