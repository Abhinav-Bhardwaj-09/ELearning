package AssistedPractice.firstOccurenceInSinglyLinkedList;

/**
 * Created by IntelliJ IDEA
 * User: Abhinav Bhardwaj
 * Date: 25/07/22
 * Time: 13:46
 */

public class firstOccurenceInSinglyLinkedList {

    private Node head;

    public void insert(int data) {
        Node newNode = new Node(data);

        if (head.getNext() == null) {
            head.setNext(newNode);
        } else {
            Node currentNode = head;
            while (currentNode.getNext() != null) {
                currentNode = currentNode.getNext();
            }
            currentNode.setNext(newNode);
        }
    }

    public int findFirstOccurence(int targetData) {
        if (head == null) {
            System.out.println("LinkedList is already empty.");
            return -1;
        }
        int index = 1;
        Node current = head;
        while (current != null) {
            if (current.getData() == targetData) {
                return index;
            }
            index++;
            current = current.getNext();
        }
        return -1;
    }

    public static void main(String[] args) {
        firstOccurenceInSinglyLinkedList FS = new firstOccurenceInSinglyLinkedList();
        FS.insert(5);
        FS.insert(3);
        FS.insert(5);
        FS.insert(3);
        FS.insert(5);
        FS.insert(3);
        FS.insert(5);
        FS.insert(3);
        // FS.insert();
        System.out.println(FS.findFirstOccurence(5));
    }
}

// 1 5 2 7 8 3 10 12 11 4 17 13 6 9 19 18 15