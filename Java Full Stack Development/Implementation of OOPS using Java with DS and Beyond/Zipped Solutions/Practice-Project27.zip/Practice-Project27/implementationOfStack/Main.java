package AssistedPractice.implementationOfStack;

/**
 * Created by IntelliJ IDEA
 * User: Abhinav Bhardwaj
 * Date: 25/07/22
 * Time: 21:53
 */


public class Main {
    public static void main(String[] args) {
        StackImplementation Stack = new StackImplementation();

        System.out.println();
        System.out.println( Stack.isEmpty() ? "Currently, Stack is empty." : "Currently, stack is not empty.");

        System.out.println();

        Stack.push(7);
        System.out.println( Stack.isEmpty() ? "Currently, Stack is empty." : "Currently, Stack is not empty.");
        System.out.println();

        Stack.push(16);
        Stack.push(5);
        Stack.push(11);

        Stack.peek();
        System.out.println();
        Stack.pop();
        System.out.println();
        Stack.peek();
        System.out.println();
        Stack.pop();
        System.out.println();
        Stack.peek();


    }
}
