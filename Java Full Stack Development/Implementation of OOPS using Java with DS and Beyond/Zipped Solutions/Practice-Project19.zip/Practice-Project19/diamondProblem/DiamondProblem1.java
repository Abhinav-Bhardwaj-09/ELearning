package AssistedPractice.diamondProblem;

/**
 * Created by IntelliJ IDEA
 *  User: Abhinav Bhardwaj
 *  Date: 23/07/2022
 *  Time: 15:39
 */

public class DiamondProblem1 implements DiamondProblemInterface{
    public void show(){
        System.out.println("Implementation 1");
    }
}
