package AssistedPractice.diamondProblem;

/**
 * Created by IntelliJ IDEA
 *  User: Abhinav Bhardwaj
 *  Date: 23/07/2022
 *  Time: 15:41
 */

public class DiamondProblem3 extends DiamondProblem1{
    /**
     *     DiamondProblem1, DiamondProblem2 both can't be extended as both the classes
     *     have implemented the same interface DiamondProblemInterface, if we try to do so,
     *     JVM will be confused to choose between the two implementations of the same interface
     */

    public static void main(String[] args) {
        DiamondProblem3 DP = new DiamondProblem3();
        DP.show();
    }
}