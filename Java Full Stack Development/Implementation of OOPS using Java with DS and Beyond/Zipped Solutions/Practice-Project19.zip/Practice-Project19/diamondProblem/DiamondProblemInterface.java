package AssistedPractice.diamondProblem;

/**
 * Created by IntelliJ IDEA
 *  User: Abhinav Bhardwaj
 *  Date: 23/07/2022
 *  Time: 17:10
 */

public interface DiamondProblemInterface {
    void show();
}
