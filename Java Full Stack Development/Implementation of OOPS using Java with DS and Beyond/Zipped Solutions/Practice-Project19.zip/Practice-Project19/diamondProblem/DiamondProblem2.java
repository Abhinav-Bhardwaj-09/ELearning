package AssistedPractice.diamondProblem;

/**
 * Created by IntelliJ IDEA
 *  User: Abhinav Bhardwaj
 *  Date: 23/07/2022
 *  Time: 15:40
 */

public class DiamondProblem2 implements DiamondProblemInterface{
    public void show(){
        System.out.println("Implementation 2");
    }
}