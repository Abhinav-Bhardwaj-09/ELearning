package AssistedPractice.OOPS;

/**
 * Created by IntelliJ IDEA
 *  User: Abhinav Bhardwaj
 *  Date: 23/07/2022
 *  Time: 16:28
 */

abstract class Car{
    String model;

    public abstract String toString();

    public Car(String model) {
        this.model = model;
    }

    public String getModel() {
        return model;
    }
}

class BMW extends Car{
    public BMW(String model) {
        super(model);
    }
    @Override
    public String toString(){
        return "Car model is :- " + super.model;
    }
}


class LandRover extends Car{
    public LandRover(String model) {
        super(model);
    }
    @Override
    public String toString(){
        return "Car model is :- " + super.model;
    }
}

public class Abstraction {
    public static void main(String[] args) {
        Car C1 = new AssistedPractice.OOPS.BMW("Q6");
        Car C2 = new AssistedPractice.OOPS.LandRover("Defender");
        System.out.println(C1.toString());
        System.out.println(C2.toString());
    }
}