package AssistedPractice.OOPS;

/**
 * Created by IntelliJ IDEA
 *  User: Abhinav Bhardwaj
 *  Date: 23/07/2022
 *  Time: 15:52
 */

public class Polymorphism {

    void print(int num){
        System.out.println("Number = " + num);
    }

    void print(String str){
        System.out.println("String = " + str);
    }

    void print(String str, int num){
        System.out.println("String = " + str + " , Number = " + num);
    }

    public static void main(String[] args) {
        Polymorphism PM = new Polymorphism();
        PM.print(1);
        PM.print("Implementation of polymorphism");
        PM.print("Implementation of polymorphism", 1);
    }
}