package AssistedPractice.OOPS;

/**
 * Created by IntelliJ IDEA
 *  User: Abhinav Bhardwaj
 *  Date: 23/07/2022
 *  Time: 15:51
 */

public class ClassAndObject {
    String attribute1;

    public ClassAndObject(String attribute){
        this.attribute1 = attribute;
    }
    public String getAttribute1(){
        return attribute1;
    }

    @Override
    public String toString(){
        return ("Example of classes and objects in OOPs :- " + this.getAttribute1());
    }

    public static void main(String[] args) {
        ClassAndObject AB = new ClassAndObject("example attribute value");
        System.out.println(AB.toString());
    }
}