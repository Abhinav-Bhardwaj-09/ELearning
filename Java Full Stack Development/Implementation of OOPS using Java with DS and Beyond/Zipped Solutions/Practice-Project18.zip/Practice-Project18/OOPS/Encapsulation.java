package AssistedPractice.OOPS;

/**
 * Created by IntelliJ IDEA
 *  User: Abhinav Bhardwaj
 *  Date: 23/07/2022
 *  Time: 15:51
 */

class Person {
    String name;

     public Person(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
}

class Vehicle{
    String type;

    public Vehicle(String type) {
        this.type = type;
    }

    public String getType() {
        return type;
    }

}

//Encapsulation refers to integrating data member and its related member functions in a same unit i.e. class
public class Encapsulation {
    public static void main(String[] args) {
        Person P = new Person("Person");
        System.out.println(P.getName());

        Vehicle V = new Vehicle("Car");
        System.out.println(V.getType());
    }
}