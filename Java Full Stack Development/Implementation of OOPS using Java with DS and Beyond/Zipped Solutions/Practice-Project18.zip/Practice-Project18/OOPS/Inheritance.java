package AssistedPractice.OOPS;

/**
 * Created by IntelliJ IDEA
 *  User: Abhinav Bhardwaj
 *  Date: 23/07/2022
 *  Time: 15:51
 */

class Parent{
    String value;
    public Parent(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String toString(){
        return "Parent class's value :- " + this.getValue();
    }
}

class Child extends Parent{
    String value;

    public Child(String value){
        super(value);
        this.value = value;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    @Override
    public String toString(){
        return super.toString() + "\n" + "Child class's value :- " + this.getValue();
    }
}

public class Inheritance {
    public static void main(String[] args) {
        Child C = new Child("from child object");
        System.out.println(C.toString());
    }
}