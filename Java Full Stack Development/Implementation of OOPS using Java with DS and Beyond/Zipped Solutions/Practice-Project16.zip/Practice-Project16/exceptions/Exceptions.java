package AssistedPractice.exceptions;

/**
 * Created by IntelliJ IDEA
 *  User: Abhinav Bhardwaj
 *  Date: 23/07/2022
 *  Time: 16:47
 */

public class Exceptions {
    public static void main(String args[]){
        try{
            //code that may raise exception
            int data=100/0;
        }
        catch(ArithmeticException e){
            System.out.println(e);
        }
        //rest code of the program
        System.out.println("Arithmetic exception caught \n");

        try{
            String s=null;
            System.out.println(s.length());//NullPointerException
        }
        catch (NullPointerException e){
            System.out.println(e);
        }
        System.out.println("NullPointerException Found\n");

        try {
            String s = "abc";
            int i = Integer.parseInt(s);//NumberFormatException
        }
        catch (NumberFormatException e){
            System.out.println(e);
        }
        System.out.println("NumberFormatException Found\n");

        try {
            int a[] = new int[5];
            a[6] = 50; //ArrayIndexOutOfBoundsException
        }
        catch (ArrayIndexOutOfBoundsException e){
            System.out.println(e);
        }
        System.out.println("ArrayIndexOutOfBoundsException Found\n");

        try {
            int num = 100/0;
        }
        catch (Exception e){
            System.out.println("The type of exception caught - " + e);
        }
    }
}