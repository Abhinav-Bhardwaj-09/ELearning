package AssistedPractice.linearSearch;

import java.util.Scanner;

/**
 * Created by IntelliJ IDEA
 * User: Abhinav Bhardwaj
 * Date: 27/07/22
 * Time: 13:55
 */


public class LinearSearch {
    int linearS (int arr[], int targetElement) {
        for (int index = 0; index < arr.length; index++) {
            if(arr[index] == targetElement) {
                return index;
            }
        }
        return -1;
    }
    public static void main(String[] args) {
        Scanner SC = new Scanner(System.in);
        LinearSearch LS = new LinearSearch();

        int arr[] = {1, 5, 2, 8, 10, 6, 11, 9, 0, 21, 7, 4, 13, 12};

        System.out.print("Target Element to be searched: ");
        int target = SC.nextInt();


        int index = LS.linearS(arr, target);
        String result = index > 0 ? "Element is present in the array at index : " + (index+1) : "Element is not present in the the array.";

        System.out.println(result);
    }
}
