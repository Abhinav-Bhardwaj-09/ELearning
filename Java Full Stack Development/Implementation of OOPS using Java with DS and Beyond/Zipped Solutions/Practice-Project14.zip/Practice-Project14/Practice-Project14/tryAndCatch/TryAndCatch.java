package AssistedPractice.tryAndCatch;

/**
 * Created by IntelliJ IDEA
 * User: Abhinav Bhardwaj
 * Date: 23/07/22
 * Time: 15:14
 */



public class TryAndCatch {
    public static void main(String[] args) {
        try {
            int n = 10 / 2;
            System.out.println("On dividing 10 by 2, we get : " + n);
            System.out.print("On dividing 10 by 0, we get ");
            n = 5/0;
        }
        catch (Exception e){
            System.out.println("error as '" + e + "'");
        }
    }
}
