package AssistedPractice.circularSinglyLinkedList;

/**
 * Created by IntelliJ IDEA
 * User: Abhinav Bhardwaj
 * Date: 26/07/22
 * Time: 13:46
 */


public class Main {
    public static void main(String[] args) {
        CircularSinglyLinkedList CSLL = new CircularSinglyLinkedList();
        CSLL.insertSorted(5);
        CSLL.insertSorted(2);
        CSLL.insertSorted(11);
        CSLL.insertSorted(1);
        CSLL.insertSorted(7);
        CSLL.insertSorted(19);
        CSLL.insertSorted(14);
        CSLL.insertSorted(6);
        CSLL.insertSorted(13);
        CSLL.display();




    }
}
