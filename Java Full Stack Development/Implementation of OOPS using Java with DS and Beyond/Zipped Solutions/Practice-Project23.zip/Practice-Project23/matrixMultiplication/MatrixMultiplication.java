package AssistedPractice.matrixMultiplication;

import java.util.Scanner;

/**
 * Created by IntelliJ IDEA
 * User: Abhinav Bhardwaj
 * Date: 26/07/22
 * Time: 00:05
 */


public class MatrixMultiplication {
    public static void main(String[] args) {
        Scanner SC = new Scanner(System.in);

        System.out.print("Number of rows in first matrix: ");
        int R1 = SC.nextInt();

        System.out.print("Number of columns in first matrix: ");
        int C1 = SC.nextInt();



        System.out.print("Number of rows in second matrix: ");
        int R2 = SC.nextInt();

        System.out.print("Number of columns in second matrix: ");
        int C2 = SC.nextInt();


        if (C1 == R2) {
            int [][] M1 = new int[R1][C1];

            System.out.println("Elements of the First Matrix :- ");
            for (int rowIndex = 0; rowIndex < R1; rowIndex++) {
                System.out.print("Elements in the row number" + (rowIndex +1) + " : " );
                for (int colIndex = 0; colIndex < C1; colIndex++) {
                    M1[rowIndex][colIndex] = SC.nextInt();
                }
                System.out.println();
            }


            int [][] M2 = new int[R2][C2];

            System.out.println("Elements of the Second Matrix :- ");
            for (int rowIndex = 0; rowIndex < R2; rowIndex++) {
                System.out.print("Elements in the row number" + (rowIndex +1) + " : " );
                for (int colIndex = 0; colIndex < C2; colIndex++) {
                    M2[rowIndex][colIndex] = SC.nextInt();
                }
                System.out.println();
            }

            int [][] M = new int[R1][C2];
            for (int rowIndex = 0; rowIndex < R1; rowIndex++) {
                for (int colIndex = 0; colIndex < C2; colIndex++) {
                    for (int rowIndex2 = 0; rowIndex2 < R2; rowIndex2++) {
                        M[rowIndex][colIndex] += M1[rowIndex][rowIndex2] * M2[rowIndex2][colIndex];
                    }
                }
            }

            for (int rowIndex = 0; rowIndex < R1; rowIndex++) {
                System.out.print("Elements in the row number" + (rowIndex +1) + " : " );
                for (int colIndex = 0; colIndex < C2; colIndex++) {
                    System.out.print(M[rowIndex][colIndex] + " ");
                }
                System.out.println();
            }

        }
        else {
            System.out.println("These two matrices can't be multiplied.");
        }
    }
}
