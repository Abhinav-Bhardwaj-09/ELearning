package AssistedPractice.implementationOfInnerClass;

/**
 * Created by IntelliJ IDEA
 * User: Abhinav Bhardwaj
 * Date: 19/07/22
 * Time: 15:51
 */


abstract class AbstractClass {
    abstract void print4();
}
