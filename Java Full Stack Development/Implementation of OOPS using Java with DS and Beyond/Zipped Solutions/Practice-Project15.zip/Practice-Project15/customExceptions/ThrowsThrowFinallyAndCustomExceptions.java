package AssistedPractice.throwsThrowFinallyAndCustomExceptions;

/**
 * Created by IntelliJ IDEA
 *  User: Abhinav Bhardwaj
 *  Date: 23/07/2022
 *  Time: 17:05
 */

public class ThrowsThrowFinallyAndCustomExceptions {

    static void function() throws IllegalAccessException
    {
        System.out.println("Inside the function");
        throw new IllegalAccessException("throw demonstrated.");
    }

    public static void main(String[] args) {
        int result;
        try {
            result = 10 / 0;
            System.out.println("result" + result);
        }

        catch (ArithmeticException e) {
            System.out.println("Division by zero :-" + e);
        }

        finally {
            System.out.println("Finally block");
        }

        try {
            function();
        }
        catch (IllegalAccessException e) {
            System.out.println("caught in main.");
        }
    }
}